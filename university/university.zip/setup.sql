CREATE TABLE students (
	sid int NOT NULL,
	name varchar(255),
	surname varchar(255),
	email varchar(255),
	faculty varchar(255),
	matriculation int
	);

CREATE TABLE professors (
	pid int NOT NULL,
	name varchar(255),
	surname varchar(255),
	email varchar(255),
	faculty varchar(255),
	telephone varchar(255)
);

CREATE TABLE courses (
	course_name varchar(255),
	pid int,
	credits int,
	subject varchar(255)
);

CREATE TABLE enrollment (
	course_name varchar(255),
	sid int
);
